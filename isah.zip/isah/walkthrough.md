# Walkthrough: Active Measurement Framework

I have completely overhauled the architecture to match your requirements for a highly technical, pure measurement tool that strips away the visual clutter and focuses strictly on mathematical output and live capture.

## 1. Unified Command Structure
The tool no longer has confusing sub-modes (`live`, `monitor`, `analyze`, `diff`). It is now a single, powerful command: `capture`.

```powershell
python main.py capture --silketw "C:\Path\To\SilkETW.exe" --provider Microsoft-Windows-Kernel-Process --filter-pid 1234 --payload-i1 poc_injector.exe --payload-i2 direct.exe --payload-i3 indirect.exe --payload-i4 hwbp.exe
```

## 2. Terminal UI & The Path Mutation Tracker
The interface is now split into three highly functional areas optimized for live presentations:

- **Left Pane (75%):** A massive, full-width `LiveTelemetryGrid`. It scrolls rapidly like Wireshark, capturing every event passing through the telemetry pipe.
- **Right Pane (25%):** The new **`MutationTracker`**. This visual state machine tracks the 4 steps of execution (Target -> Allocate -> Write -> Execute). When you inject a payload, this tracker lights up.
  - If a step is seen, it turns **[GREEN] DETECTED**.
  - If the Execution step fires, but earlier steps were missing from the telemetry, they immediately turn **[RED] MUTATED / INVISIBLE**.
- **Bottom Panel:** The `MeasurementConsole`. This is a pure text log that outputs real-time metrics for Volume, Entropy, and the formal calculation of **Telemetry Ignorance**.

## 3. Reframing the Narrative
Every reference to "EDR Blindness" has been purged from the code and the UI.
- The logs now calculate **"Telemetry Ignorance"** and **"Ignored / False Positive Deviations."**
- When malware is injected and bypasses the sensors, the tool formally measures what percentage of the telemetry was "ignored" by the provider's filtering standards.

## 4. Test Concept Payload (`poc_injector.c`)
I have written a classic C-based payload in the root of the repository: `poc_injector.c`.
This payload spawns a suspended `notepad.exe` and injects basic shellcode using standard `OpenProcess` -> `VirtualAllocEx` -> `WriteProcessMemory` -> `CreateRemoteThread`. 

**How to use it:**
1. Compile it on your Windows machine (if you have Visual Studio/cl installed):
   ```powershell
   cl.exe poc_injector.c
   ```
2. Pass the resulting `poc_injector.exe` as your `--payload-i1` argument.
3. When you run the `capture` command, press `1` to trigger it. 
4. Watch the Right Pane (Mutation Tracker). It will light up all 4 steps in Green, proving the sensor caught everything.
5. Then press `4` to launch your mutated HWBP binary. Watch the Execution step fire, while the Allocate and Write steps instantly turn Red, providing undeniable visual proof that the execution path was mutated and the sensor is blind.
